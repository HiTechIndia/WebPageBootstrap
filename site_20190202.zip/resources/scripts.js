var images = [
"180 degree direct bend test attachment for TMT Bars.jpg",
"Analogue type UTM 100 kn to 1000 kn.jpg",
"Analogue type UTM 60 tonnes capacity.jpg",
"Bend & Rebend Pane.jpg",
"Bend & Rebend Test Panes & Mandrels.jpg",
"Brinell Hardness Tester 3000 kgf with Comparetor.jpg",
"Computerised Brinell Hardness Tester 3000 kgf.jpg",
"Computerised Dynamic Balancing Machine 7 tonnes capacity.jpg",
"Computerised Servo control Hydraulic UTM with Electronic Extensometer.jpg",
"Digital Dynamic Balancing Machine 3 tonnes capacity.jpg",
"Digital Dynamic Balancing Machine 7 tonnes capacity.jpg",
"Digital Manhole Cover Testing Machine.png",
"Electronic Extensometer.jpg",
"End cum Belt Drive Computerised Balancing Machine with VFD(Variable Frequency Drive) 10 tonnes capacity.jpg",
"Mechanical cum Computerised Compression Testing Machine 100 tonnes capacity.jpg",
"Mechanical cum Computerised UTM with Digital Extensometer 100 tonnes capacity.jpg",
"Microprocessor cum Computerised laminated & coil Spring Testing Machine.jpg",
"Microprocessor cum Computerised UTM with Digital Extensometer.jpg",
"Microprocessor type UTM 40 tonnes capacity.jpg",
"Rockwell Hardness Tester.jpg",
"Roller Stand for Manhole Cover Testing Machine.jpg",
"V Table 600 mm long.jpg",
"Water Heating arrangment for TMT rebend test.jpg"
];

var basePath = "./resources/img/";

$(function(){
    var refItemDisp = $("div#refItemDispBox>div.product-container");

    $.each(images, function(index, image){
        var itemDisp = refItemDisp.clone();
        $(itemDisp).find("img").attr("src",basePath+image);
        $(itemDisp).find("span.product-description-title")
            .html(image);

        $("div#product-list").append(itemDisp);

    });

})

$(function(){
    $("div#product-list").on("click", "div.product-container", 
        function(){
            title = $(this).find("span.product-description-title").html();
            desciption = $(this).find("span.product-description-detail").html();
            imgContent = $(this).find("img").clone();

            $(imgContent).removeClass("img-thumbnail");
            $(imgContent).addClass("img-responsive");

            imgPopup(title, imgContent);
    });

    $("div.carousel").on("click", "div.item", 
        function(){
            title = $(this).find("h3").html();
            //desciption = $(this).find("span.product-description-detail").html();
            imgContent = $(this).find("img").clone();

            imgPopup(title, imgContent);
    });

})

function imgPopup(title, content){
    $("div#img-popup").find("h4.modal-title").html(title);

    $("div#img-popup").find("div.modal-body").empty();
    $("div#img-popup").find("div.modal-body").append(content.clone());

    $("div#img-popup").modal("show");
}